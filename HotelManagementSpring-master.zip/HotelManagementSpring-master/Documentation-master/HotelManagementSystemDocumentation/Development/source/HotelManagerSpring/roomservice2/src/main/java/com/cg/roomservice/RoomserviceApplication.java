package com.cg.roomservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RoomserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RoomserviceApplication.class, args);
	}
}
