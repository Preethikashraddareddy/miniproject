package com.cg.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;




import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.bean.BookingDetails;
import com.cg.bean.Hotel;
import com.cg.bean.RoomDetails;
import com.cg.bean.Users;
import com.cg.exception.BookingException;
import com.cg.util.DatabaseConnection;


public class BookingDAOImpl implements IBookingDAO{

	Connection con=null,con1=null;
	Logger logger = Logger.getRootLogger();

	public BookingDAOImpl() {
		PropertyConfigurator.configure("resources\\log4j.properties");   
		con = DatabaseConnection.getConnection(); 
		System.out.println(con);
	}


	public String generateUserId(Users user) throws BookingException{
		int id=0;
		String strId=null;
		String str = "select User_Id_Seq.nextval from dual";
		String str1;
		try {
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(str);
			while(rs.next())
			{
				id = rs.getInt(1);
			}
			str1=user.getRole();
			System.out.println(str1);
			if(str1.equalsIgnoreCase("customer"))
				strId = "U"+id;

		} catch (SQLException e) {
			logger.error("Cannot generate user id.....");
			throw new BookingException("Cannot generate user id.....");
		}
		System.out.println(strId);
		return strId;

	}

	public String generateHotelId(Hotel hotel) throws BookingException{
		int id=0;
		String strId=null;
		String str = "select Hotel_Id_Seq.nextval from dual";
		String str1;
		try {
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(str);
			while(rs.next())
			{
				id = rs.getInt(1);
			}
			
			
				strId = "H"+id;

		} catch (SQLException e) {
			logger.error("Cannot generate user id.....");
			throw new BookingException("Cannot generate user id.....");
		}
		System.out.println(strId);
		return strId;

	}
	private String generateBookingId() throws BookingException{    // Auto generation of Patient id.

		int id=0;
		String strId=null;
		String str = "select Booking_Id_Seq.nextval from dual";

		try {
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(str);
			while(rs.next())
			{
				id = rs.getInt(1);
			}

			String abc=Integer.toString(id);
			strId="B".concat(abc);
		}
		catch (SQLException e) {
			logger.error("Cannot generate user id.....");
			throw new BookingException("Cannot generate user id.....");
		}

		return strId;
	}

	@Override
	public boolean validateDetails(Users user) throws BookingException
	{

		Pattern pattern=Pattern.compile("[A-Z a-z 0-9]{5,10}");
		Matcher matcher= pattern.matcher(user.getPassword());
		if(matcher.matches()){

			pattern=Pattern.compile("[A-Z]{1}[a-z]{7}");
			matcher= pattern.matcher(user.getRole());
			if(matcher.matches()){

				pattern=Pattern.compile("[A-Z][a-z]{1,19}");
				matcher= pattern.matcher(user.getUserName());
				if(matcher.matches()){

					pattern= Pattern.compile("[0-9]{10}");
					matcher= pattern.matcher(user.getMobileNo());
					if(matcher.matches()){	

						pattern= Pattern.compile("[0-9]{10}");
						matcher= pattern.matcher(user.getPhone());
						if(matcher.matches()){	

							pattern= Pattern.compile("[a-z0-9]*@user.com");
							matcher= pattern.matcher(user.getEmail());

							if(matcher.matches()){
								return true;
							}
							else 
								throw new BookingException("Invalid Email.. ");
						}
						else
							throw new BookingException("Invalid Phone Number..");
					}
					else
						throw new BookingException("Invalid Mobile Number..");
				}
				else
					throw new BookingException("Invalid User Name..");		
			}
			else
				throw new BookingException("Invalid Role..");		
		}
		else
			throw new BookingException("Invalid Password..");	
	}

	
	@Override
	public String addUser(Users user) throws BookingException{
		user.setUserId(generateUserId(user));

		String query = "insert into husers(user_id,password,role,user_name,mobile_no,phone,address,email) values(?,?,?,?,?,?,?,?)";

		try {
			PreparedStatement ps = con.prepareStatement(query);
			
			ps.setString(1, user.getUserId());
			ps.setString(2, user.getPassword());
			ps.setString(3, user.getRole());
			ps.setString(4, user.getUserName());
			ps.setString(5, user.getMobileNo());
			ps.setString(6, user.getPhone());
			ps.setString(7, user.getAddress());
			ps.setString(8, user.getEmail());

			int row = ps.executeUpdate();
			System.out.println("10");
			logger.info(row+" User details are added successfully....");
			ps.close();
		} catch (SQLException e) {
			logger.error("Cannot add User details....");
			throw new BookingException("Cannot add User details....");  
		}
		try {
			con.close();
		} catch (SQLException e) {
			logger.error("Error in closing database connection....");
			throw new BookingException("Error in closing database connection....");
		}
		return user.getUserId();
	}
	
	
	@Override
	public String addHotel(Hotel hotel) throws BookingException{
		hotel.setHotelId(generateHotelId(hotel));
		
			String query="insert into Hotels(hotel_id, city, hotel_name, address, description, avg_rate_per_night, phone_no1, phone_no2, rating, email, fax) values(?,?,?,?,?,?,?,?,?,?,?)";
			
			try {
				PreparedStatement ps = con.prepareStatement(query);
				ps.setString(1, hotel.getHotelId());
				ps.setString(2, hotel.getCity());
				ps.setString(3, hotel.getHotelName());
				ps.setString(4, hotel.getAddress());
				ps.setString(5, hotel.getDescription());
				ps.setDouble(6, hotel.getAverageRatePerNight());
				ps.setString(7, hotel.getPhoneNo1());
				ps.setString(8, hotel.getPhoneNo2());
				ps.setString(9, hotel.getRating());
				ps.setString(10, hotel.getEmail());
				ps.setString(11, hotel.getFax());
				int row = ps.executeUpdate();
				logger.info(row+" User details are added successfully....");
				ps.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println("Cant enter hotel details into database");
				e.printStackTrace();
			}
			
			return hotel.getHotelId();
		
		}
	@Override
	public String addRoom(RoomDetails rd) throws BookingException{
		//hotel.setHotelId(generateHotelId(hotel));
		
			String query="insert into hroomdetails(hotel_id,room_id,room_no,room_type,per_night_rate,availability) values(?,?,?,?,?,?)";
			
			try {
				PreparedStatement ps = con.prepareStatement(query);
				ps.setString(1, rd.getHotelId());
				ps.setString(2, rd.getRoomId());
				ps.setString(3, rd.getRoomNo());
				ps.setString(4, rd.getRoomType());
				ps.setDouble(5, rd.getPerNightRate());
				ps.setInt(6, rd.getAvailability());
				int row = ps.executeUpdate();
				logger.info(row+" Room details are added successfully....");
				ps.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println("Cant enter hotel details into database");
				e.printStackTrace();
			}
			
			return rd.getHotelId();
		
		}
	
	
	
	@Override
	public boolean validateUser(String mobileNo, String password)
			throws BookingException {

		String query = "select User,password from husers where User_id=? and password=?";
		
		boolean flag=false;
		try {
			PreparedStatement ps = con.prepareStatement(query);
		
			ps.setString(1, mobileNo);
		
			ps.setString(2, password);
		
			ResultSet res=ps.executeQuery();
		
			while(res.next())
			{
				flag=true;
			}	
		}
		catch(Exception e)
		{

		}

		return flag;
	}

	@Override
	public List<Hotel> viewAllHotels() throws BookingException {

		List<Hotel> hotellist=new ArrayList<Hotel>();
		String query="select * from Hotels";
		try {

			PreparedStatement ps=con.prepareStatement(query);
			ResultSet res=ps.executeQuery();
			while(res.next())
			{
				Hotel h=new Hotel();
				h.setHotelId(res.getString("hotel_id"));
				h.setHotelName(res.getString("hotel_name"));
				h.setCity(res.getString("city"));
				h.setAddress(res.getString("address"));
				h.setDescription(res.getString("description"));
				h.setAverageRatePerNight(res.getDouble("avg_rate_per_night"));
				h.setRating(res.getString("rating"));
				h.setEmail(res.getString("email"));
				h.setFax(res.getString("fax"));
				h.setPhoneNo1(res.getString("phone_no1"));
				h.setPhoneNo2(res.getString("phone_no2"));
				hotellist.add(h);
				logger.info(" Hotel details are added successfully....");
			}
		}catch (SQLException e) {
			logger.error(e.getMessage());
			throw new BookingException(e.getMessage());
		}
		return hotellist;
	}

	@Override
	public List<RoomDetails> getAllRooms(String hotelId)
			throws BookingException {

		List<RoomDetails> roomDetails=new ArrayList<RoomDetails>();
		String query="select room_id,room_no,room_type,per_night_rate,availability from hroomdetails where hotel_id = ?";
		try {

			PreparedStatement ps=con.prepareStatement(query);
			ps.setString(1, hotelId);
			ResultSet res=ps.executeQuery();
			while(res.next())
			{
				RoomDetails rd=new RoomDetails();
				rd.setHotelId(hotelId);
				rd.setRoomId(res.getString("room_id"));
				rd.setRoomNo(res.getString("room_no"));
				rd.setRoomType(res.getString("room_type"));
				rd.setPerNightRate(res.getDouble("per_night_rate"));
				rd.setAvailability(res.getInt("availability"));

				roomDetails.add(rd);
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return roomDetails;
	}

	@Override
	public BookingDetails addBookingDetails(BookingDetails bookingDetails)
			throws BookingException {

		bookingDetails.setBookingId(generateBookingId());
		String sql="insert into hBookingDetails(booking_id,hotel_id,room_id,user_id,booked_from,booked_to,no_of_adults,no_of_children,amount) values(?,?,?,?,?,?,?,?,?)";
		String query="select per_night_rate from hroomdetails where room_id=?";


		try {
			PreparedStatement ps= con.prepareStatement(sql);
			ps.setString(1, bookingDetails.getBookingId());
			ps.setString(2, bookingDetails.getHotelId());
			ps.setString(3, bookingDetails.getRoomId());
			ps.setString(4,bookingDetails.getUserId());
			Date sqlDate1= Date.valueOf(bookingDetails.getBookedFrom());
			ps.setDate(5,sqlDate1);
			Date sqlDate2= Date.valueOf(bookingDetails.getBookedTo());
			ps.setDate(6,sqlDate2);
			ps.setInt(7,bookingDetails.getNumberOfAdults());
			ps.setInt(8,bookingDetails.getNumberOfChildren());
			PreparedStatement ps1=con.prepareStatement(query);
			ps1.setString(1, bookingDetails.getRoomId());
			ResultSet res=ps1.executeQuery();

			int date1=sqlDate1.getDate();
			int date2=sqlDate2.getDate();
			int days=date2-date1;
			if(days<0)
			{
				throw new BookingException("Invalid Dates");
			}
			else
			{
				Double amount=0.0;
				while(res.next())
				{
					amount=res.getDouble("per_night_rate");
				}
				amount=amount*days;
				ps.setDouble(9, amount);
				ps.executeUpdate();
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		logger.info(" Booking details are added successfully....");
		return bookingDetails;
	}



	@Override
	public BookingDetails viewBookingDetails(String bookingId)
			throws BookingException {

		BookingDetails book=new BookingDetails();
		String sql="select booking_id,room_id,user_id,booked_from,booked_to,no_of_adults,no_of_children,amount from hBookingDetails where booking_id=? ";
		LocalDate dt1=null;
		LocalDate dt2=null;
		try{
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1,bookingId);
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				String  bookId=rs.getString("booking_id");
				String roomId=rs.getString("room_id");
				String userId=rs.getString("user_id");
				Date date1=rs.getDate("booked_from");
				if(date1!=null){
					dt1=date1.toLocalDate();
				}
				Date date2=rs.getDate("booked_to");
				if(date2!=null){
					dt2=date2.toLocalDate();
				}
				int adult=rs.getInt("no_of_adults");
				int children=rs.getInt("no_of_children");
				double amt=rs.getDouble("amount");
	//			System.out.println(bookId +" "+roomId+userId+dt1+dt2+adult+children+amt);
				book.setBookingId(bookId);
				book.setRoomId(roomId);
				book.setUserId(userId);
				book.setBookedFrom(dt1);
				book.setBookedTo(dt2);
				book.setNumberOfAdults(adult);
				book.setNumberOfChildren(children);
				book.setAmount(amt);

			}
		}
		catch(SQLException e){
			e.printStackTrace();
		}	
		return book;
	}


	

@Override
public List<BookingDetails> viewBookings(LocalDate bookedFrom)throws BookingException {
	String sql="select booking_id,room_id,user_id,booked_from,booked_to,no_of_adults,no_of_children,amount from hBookingDetails where booked_from=?";
	ArrayList<BookingDetails> blist=new ArrayList<>();
	
	//System.out.println("Hi");
	
	try{
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setDate(1,Date.valueOf(bookedFrom));
		ResultSet rs=ps.executeQuery();
		//BookingDetails bd1=new BookingDetails();
		
		while(rs.next()){
			Date date1=rs.getDate("booked_from");
			Date date2=rs.getDate("booked_to");
			LocalDate dt1 = date1.toLocalDate();
			LocalDate dt2=date2.toLocalDate();
		 BookingDetails bd= new BookingDetails();
		 bd.setBookingId(rs.getString("booking_id"));
		 bd.setRoomId(rs.getString("room_id"));
		 bd.setUserId(rs.getString("user_id"));	
		 bd.setBookedFrom(dt1);
		 bd.setBookedTo(dt2);
		 bd.setNumberOfAdults(rs.getInt("no_of_adults"));
		 bd.setNumberOfChildren(rs.getInt("no_of_children"));
		 bd.setAmount(rs.getDouble("amount"));
		 blist.add(bd);	
		}
	   }  catch (SQLException e) {
			logger.error("Problem in fetching details"+e.getMessage());
			throw new BookingException("Invalid details");
		}	
	/*for (BookingDetails bookingDetails : blist) {
		System.out.println(bookingDetails);
	}*/
	return blist;


	
}


@Override
public List<BookingDetails> getGuestList(String hotelId) {
	// TODO Auto-generated method stub

	List<BookingDetails> users=new ArrayList<BookingDetails>();
	String query="select * from hbookingdetails where hotel_id = ?";
	try {

		PreparedStatement ps=con.prepareStatement(query);
		ps.setString(1, hotelId);
		ResultSet res=ps.executeQuery();
		while(res.next())
		{BookingDetails bd=new BookingDetails();
	
			bd.setHotelId(res.getString("hotel_id"));
			bd.setRoomId(res.getString("room_id"));
			bd.setUserId(res.getString("user_id"));
			users.add(bd);
		}
	}
	catch (Exception e)
	{
		e.printStackTrace();
	}
	return users;
}


@Override
public List<BookingDetails> adminViewBookingDetails(String hotelId)
		throws BookingException {
	ArrayList<BookingDetails> b1list=new ArrayList<>();
	String sql="select * from hBookingDetails where hotel_id=? ";
	try{
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setString(1,hotelId);
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			Date date1=rs.getDate("booked_from");
			Date date2=rs.getDate("booked_to");
			LocalDate dt1 = date1.toLocalDate();
			LocalDate dt2=date2.toLocalDate();
			BookingDetails bd=new BookingDetails();
			 bd.setBookingId(rs.getString("booking_id"));
			 bd.setRoomId(rs.getString("room_id"));
			 bd.setUserId(rs.getString("user_id"));	
			 bd.setBookedFrom(dt1);
			 bd.setBookedTo(dt2);
			 bd.setNumberOfAdults(rs.getInt("no_of_adults"));
			 bd.setNumberOfChildren(rs.getInt("no_of_children"));
			 bd.setAmount(rs.getDouble("amount"));
			 b1list.add(bd);	

		}
	}
	catch(SQLException e){
		e.printStackTrace();
	}
	/*for (BookingDetails bookingDetails : b1list) {
		System.out.println(bookingDetails);
	}*/
	return b1list;
}


@Override
public boolean updateRoom(RoomDetails room) throws BookingException {
	
	Scanner sc= new Scanner(System.in);
	
	/*System.out.println("Enter Hotel ID");
	String hid=sc.next();*/
	System.out.print("Enter Room no. ");
	String rno = sc.next();
	room.setRoomNo(rno);
	System.out.print("Enter Room type ");
	String rtyp = sc.next();
	room.setRoomType(rtyp);
	System.out.print(" Enter Average rate per night ");
	double average = sc.nextDouble();
	room.setPerNightRate(average);
	System.out.print("Enter Room availability");
	int avail = sc.nextInt();
	room.setAvailability(avail);
	
    String sql = "UPDATE hroomdetails SET ROOM_NO=?, ROOM_TYPE =?, PER_NIGHT_RATE=?,AVAILABILITY=? where ROOM_ID=? "; 
	con = DatabaseConnection.getConnection();
	
	PreparedStatement pst;
	try {
		pst = con.prepareStatement(sql);
		/*pst.setString(1, hid);
		pst.setString(2, rno);
		pst.setString(3, rtyp);
		pst.setDouble(4, average);
		pst.setDouble(5, avail);
		pst.setString(6, room.getRoomId());*/
		
		pst.setString(1, rno);
		pst.setString(2, rtyp);
		pst.setDouble(3, average);
		pst.setDouble(4, avail);
		pst.setString(5, room.getRoomId());
		
		pst.executeUpdate();
	} catch (SQLException e) {
	// TODO Auto-generated catch block
	throw new BookingException("Problem in updating  "+e.getMessage());
	}					
	logger.info(" Room details Updated successfully....");
	return true;
}


@Override
public int deleteRoom(RoomDetails room) throws BookingException {
	
	String sql = "DELETE FROM hroomdetails where room_id=?";
	con = DatabaseConnection.getConnection();
	
	PreparedStatement pst;
	try {
		pst = con.prepareStatement(sql);
		pst.setString(1, room.getRoomId());
		int r=pst.executeUpdate();
		logger.info("Deleted roomdetails successfully");
		return r;
	} catch (SQLException e1) {
		// TODO Auto-generated catch block
		throw new BookingException("Problem in the deleting details"+e1.getMessage());
	}
}



@Override
public boolean updateHotel(Hotel hotel) throws BookingException {
	// TODO Auto-generated method stub
	Scanner sc= new Scanner(System.in);
	System.out.print("Enter Hotel City: ");
	String city1 = sc.next();
	hotel.setCity(city1);
	System.out.print("Enter Hotel Name: ");
	String hotelName1 = sc.next();
	hotel.setHotelName(hotelName1);
	System.out.print("Enter Address ");
	String address1 = sc.next();
	hotel.setAddress(address1);
	System.out.print("Enter Description ");
	String desc1 = sc.next();
	hotel.setDescription(desc1);
	System.out.print(" Enter Average rate per night ");
	double avg1 = sc.nextDouble();
	hotel.setAverageRatePerNight(avg1);
	System.out.print("Enter Phone number 1 ");
	String phoneno11=sc.next();
	hotel.setPhoneNo1(phoneno11);
	System.out.print("Enter Phone number 2");
	String phoneno21 = sc.next();
	hotel.setPhoneNo2(phoneno21);
	System.out.println("Enter rating");
	String rating1=sc.next();
	hotel.setRating(rating1);
	System.out.println("Enter email");
	String email1=sc.next();
	hotel.setEmail(email1);
	System.out.println("Enter fax");
	String fax1=sc.next();
	hotel.setFax(fax1);
	
    String sql = "UPDATE hotels SET CITY =?, HOTEL_NAME=?, ADDRESS =?, "
    		+ "DESCRIPTION=?, "+ "AVG_RATE_PER_NIGHT=?, PHONE_NO1=?,"
    		+ " PHONE_NO2=?, RATING=?, EMAIL=?, FAX=?  where HOTEL_ID=?"; 
	con = DatabaseConnection.getConnection();
	
	PreparedStatement pst;
	try {
		pst = con.prepareStatement(sql);

		pst.setString(1, city1);
		pst.setString(2, hotelName1);
		pst.setString(3, address1);
		pst.setString(4, desc1);
		pst.setDouble(5, avg1);
		pst.setString(6,phoneno11);
		pst.setString(7, phoneno21);
		pst.setString(8, rating1);
		pst.setString(9, email1);
		pst.setString(10, fax1);
		pst.setString(11, hotel.getHotelId());
		
		pst.executeUpdate();
	} catch (SQLException e) {
	// TODO Auto-generated catch block
	throw new BookingException("Problem in updating  "+e.getMessage());
	}					
	logger.info("Hotel details updated successfully....");
	return true;
}


@Override
public int deleteHotel(String hotelId)throws BookingException {
	int r=0,l=0,m=0;
	//String del="DELETE FROM hbookingdetails where hotels_id=?";
	String query="DELETE FROM hroomdetails where hotels_id=?";
	String sql = "DELETE FROM hotels where hotels_id=?";
	con = DatabaseConnection.getConnection();
	con1 = DatabaseConnection.getConnection();
	System.out.println("hel1");
	PreparedStatement pst,pst1,pst2;
	try {
		/*pst2 = con.prepareStatement(sql);
		pst2.setString(1, hotelId);
		m=pst2.executeUpdate();*/
		System.out.println("2");
		pst1 = con1.prepareStatement(query);
		System.out.println("3");
		pst1.setString(1, hotelId);
		System.out.println("4");
		l=pst1.executeUpdate();
		pst1.close();
		System.out.println("5");
		con1.close();
		/*pst = con.prepareSt
		 * atement(sql);
		pst.setString(1, hotelId);
		System.out.println("hi");
		 r=pst.executeUpdate();
		con.close();*/
	} catch (SQLException e1) {
		// TODO Auto-generated catch block
		throw new BookingException("Problem in the deleting details"+e1.getMessage());
	}
	return l;
}
}	

