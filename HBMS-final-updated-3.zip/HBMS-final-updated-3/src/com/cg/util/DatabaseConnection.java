package com.cg.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DatabaseConnection {

	public static Connection getConnection()
	{
		Connection con = null;
		
		String url="", driver="",username="",pwd="";
		
		try {
			InputStream in = new FileInputStream("resources\\connection_details.properties");
			Properties prop = new Properties();
			prop.load(in);
			url = prop.getProperty("url");
			driver = prop.getProperty("driver");
			username = prop.getProperty("username");
			pwd = prop.getProperty("password");
			
			Class.forName(driver);
			con = DriverManager.getConnection(url, username, pwd);
			System.out.println("Database connected successfully...");
			
		} catch (FileNotFoundException e) {
			System.out.println(".properties file not found....");
		} catch (IOException e) {
			System.out.println(".properties file not loaded.....");
		} catch (ClassNotFoundException e) {
			System.out.println("Driver Not Found....");
		} catch (SQLException e) {
			System.out.println("Connection not Established...");
		}
		return con;
	}
}
